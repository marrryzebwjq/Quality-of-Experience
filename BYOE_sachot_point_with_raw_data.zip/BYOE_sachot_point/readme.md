Dataset : IRCCyN/IVC DIBR Videos

[ftp://ftp.ivc.polytech.univ-nantes.fr/IRCCyN_IVC_DIBR_Videos/](ftp://ftp.ivc.polytech.univ-nantes.fr/IRCCyN_IVC_DIBR_Videos/)